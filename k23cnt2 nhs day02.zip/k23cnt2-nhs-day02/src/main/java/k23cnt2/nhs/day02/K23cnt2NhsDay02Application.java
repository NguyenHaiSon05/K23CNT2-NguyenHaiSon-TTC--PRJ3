package k23cnt2.nhs.day02;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class K23cnt2NhsDay02Application {

	public static void main(String[] args) {
		SpringApplication.run(K23cnt2NhsDay02Application.class, args);
	}

}
