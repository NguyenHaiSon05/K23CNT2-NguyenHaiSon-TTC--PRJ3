package k23cnt2.nhs.day02;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class K23cnt2NhsDay02ApplicationTests {

	@Test
	void contextLoads() {
	}

}
